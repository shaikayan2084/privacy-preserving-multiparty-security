# 🔐 Privacy-Preserving Data Collaboration via SMPC

**B.Tech Final Year Project | Dept. CIC | Vasireddy Venkatadri Institute of Technology, Nambur**  
A.Y. 2025–2026 | Guide: Y. Suresh, Associate Professor

---

## 🚀 Quick Start (Local Development)

### 1. Clone the repository
```bash
git clone https://github.com/shaikayan2084/privacy-preserving-multiparty-security.git
cd privacy-preserving-multiparty-security
```

### 2. Create & activate virtual environment
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# macOS / Linux
source venv/bin/activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure environment
```bash
# Copy the sample .env and fill in your values
cp .env.example .env
```
Edit `.env` — set your email credentials (Gmail with App Password recommended).

### 5. Run the application
```bash
python app.py
```

Open your browser at: **http://127.0.0.1:5000**

---

## 🔑 Default Admin Account
After first run, a default admin is created:
- **Email:** `admin@smpc.local`
- **Password:** `Admin@1234`
- ⚠️ Change this immediately after first login!

---

## 📂 Project Structure
```
privacy-preserving-multiparty-security/
├── app.py                  # Main Flask app — all routes & security logic
├── requirements.txt        # Python dependencies
├── .env                    # Environment variables (NOT in git)
├── .gitignore
├── logs/                   # Security & app logs (auto-created)
├── templates/
│   ├── base.html           # Shared layout
│   ├── auth/               # Login, signup, MFA, password reset
│   ├── dashboard/          # User dashboard, profile, admin panel
│   ├── pages/              # Public pages (home, about, etc.)
│   └── errors/             # 403, 404, 429, 500 error pages
└── static/                 # CSS, JS, images
```

---

## 🛡️ Security Features Implemented

| Feature | Implementation |
|---------|----------------|
| Rate Limiting | Flask-Limiter: 20/min login, 5/hr reset |
| Brute Force Protection | Lock after 5 fails for 15 minutes |
| Password Hashing | bcrypt with 12 rounds + salt |
| Email Verification | SHA-256 token, 24hr expiry |
| Password Reset | Single-use token, 30min expiry |
| MFA / 2FA | TOTP via Google Authenticator / Authy |
| CSRF Protection | Flask-WTF CSRF tokens on all forms |
| Session Security | HttpOnly cookies, session rotation on login |
| Session Expiry | 1-hour automatic expiry |
| Generic Error Messages | Never reveals if email exists |
| RBAC | Admin / User roles enforced server-side |
| SQL Injection Prevention | SQLAlchemy ORM parameterized queries |
| Security Logging | All login attempts logged with IP |
| Account Lockout | Temporary lock with configurable duration |

---

## 🔌 API Endpoints

| Method | URL | Auth | Description |
|--------|-----|------|-------------|
| POST | `/api/smpc/simulate` | Required | Run SMPC simulation |
| GET | `/api/stats` | Required | System statistics |

---

## 👥 Team Members
- P. Radha Krishna Sai (22BQ1A4774)
- Shaik Ayan (23BQ5A4709)
- V. Jaswanth Kumar (23BQ5A4710)
- D. Sai Aditya (23BQ5A4713)

---

## 📖 Opening in VS Code
```bash
code .
```
Or open the folder `D:\privacy-preserving-multiparty-security` in VS Code.

To run from VS Code terminal:
```bash
# Activate venv first
venv\Scripts\activate   # Windows
python app.py
```

---

## ⚠️ Production Notes
- Set `SESSION_COOKIE_SECURE = True` when using HTTPS
- Use PostgreSQL instead of SQLite for production
- Configure a real SMTP server for emails
- Rotate `SECRET_KEY` in production
- Never commit `.env` to git
